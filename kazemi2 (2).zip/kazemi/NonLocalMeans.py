import cv2
import numpy as np


img11 = cv2.imread('img11.jpg', cv2.IMREAD_GRAYSCALE)

if img11 is None:
    print("Error: تصویر بارگذاری نشد.")
else:
   
    poisson_noise = np.random.poisson(lam=30, size=img11.shape).astype(np.uint8)  
    noisy_image = cv2.add(img11, poisson_noise)  

    
    denoised_image = cv2.fastNlMeansDenoising(noisy_image, None, 10, 7, 21)

   
    cv2.imshow("Original Image", img11)
    cv2.imshow("Poisson Noisy Image", noisy_image)
    cv2.imshow("Denoised Image (Non-Local Means)", denoised_image)

  
    cv2.waitKey(0)
    cv2.destroyAllWindows()