import cv2
import numpy as np


img11 = cv2.imread('img11.jpg', cv2.IMREAD_GRAYSCALE)

if img11 is None:
    print("Error: تصویر بارگذاری نشد.")
else:
    
    noise = np.random.normal(0, 25, img11.shape).astype(np.uint8)  
    noisy_image = cv2.add(img11, noise) 

 
    mean_filtered_image = cv2.blur(noisy_image, (5, 5))  

   
    cv2.imshow("Original Image", img11)
    cv2.imshow("Noisy Image", noisy_image)
    cv2.imshow("Mean Filtered Image", mean_filtered_image)


    cv2.waitKey(0)
    cv2.destroyAllWindows()
