import cv2


def zoom_out_image(image_path, zoom_factor):
  
    image = cv2.imread(image_path)

   
    if image is None:
        print("Image not found. Please check the file path.")
        return

 
    original_height, original_width = image.shape[:2]

 
    new_width = int(original_width / zoom_factor)
    new_height = int(original_height / zoom_factor)

  
    zoomed_image = cv2.resize(image, (new_width, new_height))

  
    canvas = cv2.resize(zoomed_image, (original_width, original_height))

  
    cv2.imshow("Zoomed Out Image", canvas)
    cv2.waitKey(0)
    cv2.destroyAllWindows()


image_path_input = input("Please enter the path to the image: ")
zoom_factor_input = float(input("Enter the zoom factor (e.g., 0.5 for zoom out): "))


zoom_out_image(image_path_input, zoom_factor_input)